import java.applet.Applet;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class KeyStatusApplet extends Applet implements KeyListener {
    String msg = "";
    int x = 10, y = 50;
    
    public void init() {
        addKeyListener(this); // Register key listener
        requestFocus(); // Request focus to receive key events
    }
    
    public void keyPressed(KeyEvent ke) {
        msg = "Key Pressed: " + ke.getKeyChar();
        repaint();
    }
    
    public void keyReleased(KeyEvent ke) {
        msg = "Key Released: " + ke.getKeyChar();
        repaint();
    }
    
    public void keyTyped(KeyEvent ke) {
        msg = "Key Typed: " + ke.getKeyChar();
        repaint();
    }
    
    public void paint(Graphics g) {
        g.drawString(msg, x, y);
    }
}