import java.net.*;

public class InetAddressDemo {
    public static void main(String[] args) {
        try {
            // Using getByName() to get InetAddress object for a specific host
            InetAddress inetAddress = InetAddress.getByName("www.google.com");
            System.out.println("IP Address of www.google.com: " + inetAddress.getHostAddress());
            System.out.println("Host Name: " + inetAddress.getHostName());
            
            // Using getLocalHost() to get the InetAddress of the local machine
            InetAddress localAddress = InetAddress.getLocalHost();
            System.out.println("Local Machine IP Address: " + localAddress.getHostAddress());
            System.out.println("Local Host Name: " + localAddress.getHostName());
            
            // Using getAllByName() to get all IP addresses of a host
            InetAddress[] allAddresses = InetAddress.getAllByName("www.google.com");
            System.out.println("\nAll IP Addresses of www.google.com:");
            for (InetAddress addr : allAddresses) {
                System.out.println(addr.getHostAddress());
            }
        } catch (UnknownHostException e) {
            System.out.println("Error: Unable to resolve host");
            e.printStackTrace();
        }
    }
}