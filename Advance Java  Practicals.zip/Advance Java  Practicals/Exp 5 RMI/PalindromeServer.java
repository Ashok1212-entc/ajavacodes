import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;

/**
 * Server implementation for the Palindrome Checker service.
 */
public class PalindromeServer implements PalindromeChecker {
    /**
     * Checks if a string is a palindrome.
     * A string is a palindrome if it reads the same backward as forward.
     */
    @Override
    public boolean isPalindrome(String input) throws RemoteException {
        if (input == null || input.isEmpty()) {
            return false;
        }
        
        // Remove spaces and convert to lowercase for more flexible checking
        String cleanInput = input.replaceAll("\\s+", "").toLowerCase();
        int left = 0;
        int right = cleanInput.length() - 1;
        
        while (left < right) {
            if (cleanInput.charAt(left) != cleanInput.charAt(right)) {
                return false;
            }
            left++;
            right--;
        }
        return true;
    }

    /**
     * Checks if a number is a palindrome.
     * A number is a palindrome if it reads the same backward as forward.
     */
    @Override
    public boolean isPalindrome(int number) throws RemoteException {
        // Handle negative numbers
        if (number < 0) {
            return false; // Negative numbers can't be palindromes due to the minus sign
        }
        
        // Convert to string and use the string palindrome checker
        return isPalindrome(Integer.toString(number));
    }

    public static void main(String[] args) {
        try {
            // Create an instance of the server
            PalindromeServer server = new PalindromeServer();
            
            // Export the remote object
            PalindromeChecker stub = (PalindromeChecker) UnicastRemoteObject.exportObject(server, 0);
            
            // Create and start the registry on port 1099
            Registry registry = LocateRegistry.createRegistry(1099);
            
            // Bind the remote object's stub in the registry
            registry.rebind("PalindromeChecker", stub);
            
            System.out.println("Palindrome Server is running...");
            System.out.println("Press Ctrl+C to stop the server.");
        } catch (Exception e) {
            System.err.println("Server exception: " + e.toString());
            e.printStackTrace();
        }
    }
}