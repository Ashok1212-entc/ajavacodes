import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Scanner;

/**
 * Client application for the Palindrome Checker service.
 */
public class PalindromeClient {
    public static void main(String[] args) {
        try {
            // Get the registry
            Registry registry = LocateRegistry.getRegistry("localhost", 1099);
            
            // Look up the remote object from the registry
            PalindromeChecker checker = (PalindromeChecker) registry.lookup("PalindromeChecker");
            
            // Create scanner for user input
            Scanner scanner = new Scanner(System.in);
            
            while (true) {
                System.out.println("\n=== Palindrome Checker Application ===");
                System.out.println("1. Check if a string is a palindrome");
                System.out.println("2. Check if a number is a palindrome");
                System.out.println("3. Exit");
                System.out.print("Enter your choice (1-3): ");
                
                int choice = scanner.nextInt();
                scanner.nextLine(); // Consume newline
                
                switch (choice) {
                    case 1:
                        System.out.print("Enter a string: ");
                        String stringInput = scanner.nextLine();
                        boolean isStringPalindrome = checker.isPalindrome(stringInput);
                        System.out.println("\"" + stringInput + "\" is " + 
                            (isStringPalindrome ? "a palindrome." : "not a palindrome."));
                        break;
                        
                    case 2:
                        System.out.print("Enter a number: ");
                        int numberInput = scanner.nextInt();
                        scanner.nextLine(); // Consume newline
                        boolean isNumberPalindrome = checker.isPalindrome(numberInput);
                        System.out.println(numberInput + " is " + 
                            (isNumberPalindrome ? "a palindrome." : "not a palindrome."));
                        break;
                        
                    case 3:
                        System.out.println("Exiting the application...");
                        scanner.close();
                        return;
                        
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            }
        } catch (Exception e) {
            System.err.println("Client exception: " + e.toString());
            e.printStackTrace();
        }
    }
}