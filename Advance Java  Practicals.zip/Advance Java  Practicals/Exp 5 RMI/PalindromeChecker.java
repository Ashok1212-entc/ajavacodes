import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 * Remote interface for the Palindrome Checker service.
 * Defines methods that can be invoked remotely.
 */
public interface PalindromeChecker extends Remote {
    /**
     * Checks if a string is a palindrome.
     *
     * @param input The string to check
     * @return true if the string is a palindrome, false otherwise
     * @throws RemoteException if a remote communication error occurs
     */
    boolean isPalindrome(String input) throws RemoteException;

    /**
     * Checks if a number is a palindrome.
     *
     * @param number The number to check
     * @return true if the number is a palindrome, false otherwise
     * @throws RemoteException if a remote communication error occurs
     */
    boolean isPalindrome(int number) throws RemoteException;
}