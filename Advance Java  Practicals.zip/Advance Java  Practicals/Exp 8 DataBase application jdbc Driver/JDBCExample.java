import java.sql.*;

public class JDBCExample {
    public static void main(String[] args) {

        String url = "jdbc:mysql://localhost:3306/testdb";
        String user = "root"; // Change to your MySQL username
        String password = "Nitin@9099"; // Change to your MySQL password

        try (Connection conn = DriverManager.getConnection(url, user, password);
             Statement stmt = conn.createStatement()) {

            // Insert Data
            stmt.executeUpdate("INSERT INTO users (name, email) VALUES ('Nitin Selukar', 'nitin@example.com')");
            stmt.executeUpdate("INSERT INTO users (name, email) VALUES ('Kishor Selukar', 'kishor@example.com')");

            // Fetch Data
            ResultSet rs = stmt.executeQuery("SELECT * FROM users");

            while (rs.next()) {
                System.out.println("ID: " + rs.getInt("id") +
                                   ", Name: " + rs.getString("name") +
                                   ", Email: " + rs.getString("email"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
