import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class CalculatorServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int a = Integer.parseInt(request.getParameter("a"));
        int b = Integer.parseInt(request.getParameter("b"));
        String op = request.getParameter("op");
        int result = 0;

        if (op.equals("+")) result = a + b;
        else if (op.equals("-")) result = a - b;

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<h2>Result: " + result + "</h2>");
        out.println("<a href='index.html'>Try Again</a>");
    }
}
