import java.awt.*;
import java.awt.event.*;

public class FrameMouseEvents extends Frame implements MouseListener {
    Label label;
    
    public FrameMouseEvents() {
        super("AWT Mouse Events Example");
        // Set up the frame
        label = new Label("Move the mouse to interact", Label.CENTER);
        label.setBounds(50, 100, 200, 30);
        this.add(label);
        this.setSize(300, 300);
        this.setLayout(null);
        this.setLocationRelativeTo(null); //Center the frame on the screen
        this.setVisible(true); // Make frame visible initially
        
        // Add MouseListener
        this.addMouseListener(this);
        
        // Close window on exit
        this.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                dispose();
            }
        });
    }
    
    public static void main(String[] args) {
        new FrameMouseEvents();
    }
    
    @Override
    public void mouseClicked(MouseEvent e) {
        label.setText("Mouse Clicked");
    }
    
    @Override
    public void mouseEntered(MouseEvent e) {
        label.setText("Mouse Entered");
    }
    
    @Override
    public void mouseExited(MouseEvent e) {
        label.setText("Mouse Exited");
    }
    
    @Override
    public void mousePressed(MouseEvent e) {
        // Not used
    }
    
    @Override
    public void mouseReleased(MouseEvent e) {
        // Not used
    }
}