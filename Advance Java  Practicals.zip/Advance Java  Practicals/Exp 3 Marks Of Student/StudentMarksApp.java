import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class StudentMarksApp extends JFrame implements ActionListener {
    private JTextField nameField, subject1Field, subject2Field, subject3Field, subject4Field, subject5Field;
    private JButton submitButton;
    
    public StudentMarksApp() {
        // Frame properties
        setTitle("Student Marks Entry");
        setSize(400, 300);
        setLayout(new GridLayout(7, 2, 10, 10));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        // Creating labels and text fields
        add(new JLabel("Student Name:"));
        nameField = new JTextField(20);
        add(nameField);
        
        add(new JLabel("Marks for Subject 1:"));
        subject1Field = new JTextField(5);
        add(subject1Field);
        
        add(new JLabel("Marks for Subject 2:"));
        subject2Field = new JTextField(5);
        add(subject2Field);
        
        add(new JLabel("Marks for Subject 3:"));
        subject3Field = new JTextField(5);
        add(subject3Field);
        
        add(new JLabel("Marks for Subject 4:"));
        subject4Field = new JTextField(5);
        add(subject4Field);
        
        add(new JLabel("Marks for Subject 5:"));
        subject5Field = new JTextField(5);
        add(subject5Field);
        
        // Submit button
        submitButton = new JButton("Show Result");
        submitButton.addActionListener(this);
        add(submitButton);
        
        setVisible(true);
    }
    
    // Action listener to process button click
    public void actionPerformed(ActionEvent e) {
        try {
            // Get input values
            String name = nameField.getText();
            int marks1 = Integer.parseInt(subject1Field.getText());
            int marks2 = Integer.parseInt(subject2Field.getText());
            int marks3 = Integer.parseInt(subject3Field.getText());
            int marks4 = Integer.parseInt(subject4Field.getText());
            int marks5 = Integer.parseInt(subject5Field.getText());
            
            // Calculate total and percentage
            int total = marks1 + marks2 + marks3 + marks4 + marks5;
            double percentage = (double) total / 5;
            
            // Determine grade
            String grade;
            if (percentage >= 90) {
                grade = "A+";
            } else if (percentage >= 80) {
                grade = "A";
            } else if (percentage >= 70) {
                grade = "B";
            } else if (percentage >= 60) {
                grade = "C";
            } else if (percentage >= 50) {
                grade = "D";
            } else {
                grade = "F";
            }
            
            // Show result in a new window
            showResult(name, total, percentage, grade);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter valid numeric marks!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // Method to show result in a new window
    private void showResult(String name, int total, double percentage, String grade) {
        JFrame resultFrame = new JFrame("Student Result");
        resultFrame.setSize(300, 200);
        resultFrame.setLayout(new GridLayout(5, 1, 10, 10));
        resultFrame.add(new JLabel("Student Name: " + name));
        resultFrame.add(new JLabel("Total Marks: " + total));
        resultFrame.add(new JLabel("Percentage: " + String.format("%.2f", percentage) + "%"));
        resultFrame.add(new JLabel("Grade: " + grade));
        resultFrame.setVisible(true);
    }
    
    public static void main(String[] args) {
        new StudentMarksApp();
    }
}